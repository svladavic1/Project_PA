/*
 * File:   newmain.c
 * Author: KANDIC ELMA, BORACIC ASIJA, SALKO VLADAVIC
 *
 * Created on January 25, 2023, 10:59 AM
 */


#include <xc.h>
#pragma config FOSC=HS,WDTE=OFF,PWRTE=OFF,MCLRE=ON,CPD=OFF
#pragma config IESO=OFF,FCMEN=OFF,WRT=OFF,VCAPEN=OFF,PLLEN=OFF,STVREN=OFF,LVP=OFF
#define _XTAL_FREQ 8000000

//number array for 7SEG with a common anode
const char numbers[]={0b01000000, 0b01111001, 0b00100100, 0b00110000, 0b00011001, 0b0010010, 0b00000010, 0b01111000, 0b00000000, 0b0010000};//Zajednicka anoda  
char tens = 0, ones = 1;
int distance; 
char i = 0;

void init_ports(){
    //7SEG
    ANSELD = 0x00;        
    TRISD = 0b00000000;   
    PORTD = 0xFF;         //7SEG initially OFF
    //SENSOR
    ANSELB = 0;           
    TRISB0 = 0;           //RB0 OUTPUT (TRIGGER)
    TRISB4 = 1;           //RB4 INPUT (ECHO)                         
    //TRANSISTORS
    TRISB6 = 0;           //RB6 - used for ones
    TRISB7 = 0;           //RB7 - used for tens
    //DIODE
    TRISB2 = 0;           
    PORTBbits.RB2 = 0;                          
    TRISC3 = 0; 
    //SPEAKER
    PORTCbits.RC3 = 0;
}

void init_interrupts(){
    IOCIE = 1;      //interrupt on change ENABLED
    IOCIF = 0;     
    T1CON = 0X10;   //Prescale value set to 2 
    IOCBP4 = 1;     //POSITIVE EDGE DETECTION on RB4 (ECHO)
    IOCBN4 = 1;     //NEGATIVE EDGE DETECTION on RB4 (ECHO)
    GIE = 1;        //Global interrupt  ENABLED    
}
//Function used to turn the speaker on 
void ringing() {
    i = 0;
    while(i < 10){
        PORTCbits.RC3 = 0;
        __delay_us(100);
        PORTCbits.RC3 = 1;
        __delay_us(400);
        i++;
    }
}
void __interrupt()ISR(void){
    if (IOCIF){             //Interrupt on change detected
        GIE = 0; 
        if(PORTBbits.RB4)   //POSITIVE edge DETECTED
            TMR1ON = 1;     //START Timer1
        else                //NEGATIVE edge DETECTED
        {
            TMR1ON = 0;     // STOP Timer1
            distance = (TMR1L | (TMR1H<<8)) / 58.309; 
            
            //Distance WARNING (obstacle too far away or too close)
            if(distance > 99 || distance < 2) {     
                tens = 0; 
                ones = 1;
            }
            else
            {
                tens = distance/10;
                ones = distance%10;
            }
        } 
        IOCIF = 0;          //RESET interrupt on change flag
        IOCBF4 = 0;         //RESET interrupt flag on RB4
        PORTCbits.RC3 = 0;
        if(distance <= 15){
            PORTBbits.RB2 = 1;
            ringing();   
        }
        else PORTBbits.RB2 = 0;
        GIE = 1;            //ENABLE global interrupt
    }
}
 
void main(void) {
    init_ports();
    init_interrupts();   
    PORTBbits.RB7 = 0;              //Transistors OFF
    PORTBbits.RB6 = 0;
    while(1){
        TMR1H = 0;                  //RESET Timer1
        TMR1L = 0;
        PORTBbits.RB0 = 1;          //ACTIVATE trigger
        __delay_us(10);
        PORTBbits.RB0 = 0;          //DISABLE trigger
        __delay_ms(10);             //Waiting for ECHO
                               
        /*-- AFTER THE INTERRUPT ROUTINE --*/
        PORTBbits.RB6 = 0;
        PORTBbits.RB7 = 0;
        
        LATD = numbers[tens];       //SHOW tens
        PORTBbits.RB7 = 1;              
        __delay_ms(10);
        PORTBbits.RB7 = 0;
        PORTBbits.RB6 = 0;
        
        LATD = numbers[ones];       //SHOW ones
        PORTBbits.RB6 = 1;          
        __delay_ms(5);
        PORTBbits.RB6 = 0;
        PORTBbits.RB7 = 0;  
    }
    return;

}